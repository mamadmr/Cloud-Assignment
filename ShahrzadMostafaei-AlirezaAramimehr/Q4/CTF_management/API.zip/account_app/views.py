from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from account_app.utils import app
from account_app.serializers import ContainerSerializer,ContainerControlSerializer
from account_app.models import Container

from redis import Redis

redis_client = Redis(host='localhost',port=6379,db=0)

class StartContainerAPIView(APIView):
    def post(self, request):
        serializer = ContainerSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()

            
            validated_data = serializer.validated_data
            user = validated_data['user']  
            image_name = validated_data['image_name']
            container_name = validated_data['container_name'] +'-ID-'+str(user.pk)
            ports = {}

            task = app.send_task('tasks.start_ctf_container', args=[image_name, container_name, ports])
            container_id = task.get()["container_id"]
            redis_client.set('container_id', container_id)
            return Response({"message": "Container starting", "task_id": task.id, "Container_id":container_id}, status=status.HTTP_202_ACCEPTED)


class StopContainerAPIView(APIView):
    def post(self, request):
            container_id = redis_client.get('container_id')
            if not container_id:
                return Response({"error": "container_id is required"}, status=status.HTTP_400_BAD_REQUEST)
            container_id = container_id.decode()  


            if not container_id:
                return Response({"error": "container_id is required"}, status=status.HTTP_400_BAD_REQUEST)

            task = app.send_task('tasks.stop_ctf_container', args=[container_id])
            return Response({"message": "Container Stopping", "task_id": task.id, "Container_id":container_id}, status=status.HTTP_202_ACCEPTED)



class RemoveConatinerAPIView(APIView):

    def post(self, request):
        serializer = ContainerControlSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.validated_data['user']
            container = Container.objects.get(user=user)
            container.delete()

            container_id = redis_client.get('container_id')
            if not container_id:
                return Response({"error": "container_id is required"}, status=status.HTTP_400_BAD_REQUEST)
            container_id = container_id.decode()  


            if not container_id:
                return Response({"error": "container_id is required"}, status=status.HTTP_400_BAD_REQUEST)

            task = app.send_task('tasks.remove_ctf_container', args=[container_id])
            return Response({"message": "Container Removing", "task_id": task.id, "Container_id":container_id}, status=status.HTTP_202_ACCEPTED)
        
